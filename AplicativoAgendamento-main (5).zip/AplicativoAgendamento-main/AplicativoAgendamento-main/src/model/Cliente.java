package model;

public class Cliente implements Comparable<Cliente> {
    private String nome;
    private String telefone;
    private int id;
    private int prioridade;

    public Cliente(String nome, String telefone, int id, int prioridade) {
        this.nome = nome;
        this.telefone = telefone;
        this.id = id;
        this.prioridade = prioridade;
    }

    public String getNome() { return nome; }
    public String getTelefone() { return telefone; }
    public int getId() { return id; }
    public int getPrioridade() { return prioridade; }

    @Override
    public String toString() {
        return nome + " (ID: " + id + ", Prioridade: " + prioridade + ")";
    }

    @Override
    public int compareTo(Cliente outro) {
        return Integer.compare(this.prioridade, outro.prioridade);
    }

    public String toCSV() {
        return nome + ";" + telefone + ";" + id + ";" + prioridade;
    }

    public static Cliente fromCSV(String linha) {
        String[] partes = linha.split(";");
        return new Cliente(partes[0], partes[1], Integer.parseInt(partes[2]), Integer.parseInt(partes[3]));
    }
}