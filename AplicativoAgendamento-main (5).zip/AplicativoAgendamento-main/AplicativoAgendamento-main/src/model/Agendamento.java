package model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Agendamento {
    private Cliente cliente;
    private Date dataHora;
    private Servico servico;

    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public Agendamento(Cliente cliente, Date dataHora, Servico servico) {
        this.cliente = cliente;
        this.dataHora = dataHora;
        this.servico = servico;
    }

    public Cliente getCliente() { return cliente; }
    public Date getDataHora() { return dataHora; }
    public Servico getServico() { return servico; }

    @Override
    public String toString() {
        return cliente.getNome() + " - " + sdf.format(dataHora) + " - " + servico.getNome();
    }

    public String toCSV() {
        return cliente.getId() + ";" + sdf.format(dataHora) + ";" + servico.getNome();
    }

    public static Agendamento fromCSV(String linha) {
        try {
            String[] partes = linha.split(";");
            int idCliente = Integer.parseInt(partes[0]);
            Date data = sdf.parse(partes[1]);
            String nomeServico = partes[2];

            Cliente cliente = Sistema.clientes.stream()
                    .filter(c -> c.getId() == idCliente)
                    .findFirst()
                    .orElseThrow();

            Servico servico = Sistema.servicos.stream()
                    .filter(s -> s.getNome().equals(nomeServico))
                    .findFirst()
                    .orElseThrow();

            return new Agendamento(cliente, data, servico);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}