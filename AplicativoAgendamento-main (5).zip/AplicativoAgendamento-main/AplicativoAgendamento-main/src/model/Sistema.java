package model;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Sistema {
    public static List<Cliente> clientes = new ArrayList<>();
    public static PriorityQueue<Cliente> filaEspera = new PriorityQueue<>();
    public static List<Servico> servicos = new ArrayList<>();
    public static List<Agendamento> agendamentos = new ArrayList<>();

    private static final String ARQ_CLIENTES = "clientes.txt";
    private static final String ARQ_SERVICOS = "servicos.txt";
    private static final String ARQ_AGENDAMENTOS = "agendamentos.txt";
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public static void inicializarSistema() {
        carregarClientes();
        carregarServicos();
        carregarAgendamentos();
    }

    public static void adicionarCliente(Cliente c) {
        clientes.add(c);
        filaEspera.offer(c);
        salvarClientes();
    }

    public static void salvarClientes() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARQ_CLIENTES))) {
            for (Cliente c : clientes) {
                writer.println(c.toCSV());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void carregarClientes() {
        clientes.clear();
        filaEspera.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQ_CLIENTES))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                Cliente c = Cliente.fromCSV(linha);
                clientes.add(c);
                filaEspera.offer(c);
            }
        } catch (IOException e) {
            // Arquivo pode não existir ainda — tudo bem
        }
    }

    public static void salvarServicos() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARQ_SERVICOS))) {
            for (Servico s : servicos) {
                writer.println(s.toCSV());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void carregarServicos() {
        servicos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQ_SERVICOS))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                servicos.add(Servico.fromCSV(linha));
            }
        } catch (IOException e) {
            // Sem problemas se o arquivo ainda não existir
        }
    }

    public static void salvarAgendamentos() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARQ_AGENDAMENTOS))) {
            for (Agendamento a : agendamentos) {
                writer.println(a.toCSV());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void carregarAgendamentos() {
        agendamentos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQ_AGENDAMENTOS))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                agendamentos.add(Agendamento.fromCSV(linha));
            }
        } catch (IOException e) {
            // ok
        }
    }
}