package model;

public class Servico {
    private String nome;
    private int duracao; // em minutos
    private double valor;

    public Servico(String nome, int duracao, double valor) {
        this.nome = nome;
        this.duracao = duracao;
        this.valor = valor;
    }

    public String getNome() { return nome; }
    public int getDuracao() { return duracao; }
    public double getValor() { return valor; }

    @Override
    public String toString() {
        return nome + " (" + duracao + " min, R$" + valor + ")";
    }

    public String toCSV() {
        return nome + ";" + duracao + ";" + valor;
    }

    public static Servico fromCSV(String linha) {
        String[] partes = linha.split(";");
        return new Servico(partes[0], Integer.parseInt(partes[1]), Double.parseDouble(partes[2]));
    }
}