package view;

import javax.swing.*;
import java.awt.*;
import model.Servico;
import model.Sistema;

public class TelaCadastrarServico extends JFrame {

    public TelaCadastrarServico() {
        setTitle("Cadastrar Serviço");
        setSize(500, 320);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fundo = new Color(240, 245, 255);
        Color destaque = new Color(45, 120, 240);
        Color hover = new Color(30, 100, 200);
        Color branco = Color.WHITE;

        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        painelPrincipal.setBackground(fundo);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setBackground(branco);
        painelForm.setPreferredSize(new Dimension(380, 250));
        painelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(destaque, 2, true),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblTitulo = new JLabel("Cadastrar Serviço");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(destaque);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        painelForm.add(lblTitulo, gbc);

        // Nome
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.weightx = 0;
        painelForm.add(new JLabel("Nome do Serviço:"), gbc);

        JTextField txtNome = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(txtNome, gbc);

        // Duração
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        painelForm.add(new JLabel("Duração (minutos):"), gbc);

        JTextField txtDuracao = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(txtDuracao, gbc);

        // Valor
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        painelForm.add(new JLabel("Valor (R$):"), gbc);

        JTextField txtValor = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(txtValor, gbc);

        // Botão
        JButton btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCadastrar.setBackground(destaque);
        btnCadastrar.setForeground(Color.WHITE);
        btnCadastrar.setFocusPainted(false);
        btnCadastrar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        btnCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCadastrar.setBackground(hover);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCadastrar.setBackground(destaque);
            }
        });

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        painelForm.add(btnCadastrar, gbc);

        btnCadastrar.addActionListener(e -> {
            try {
                String nome = txtNome.getText().trim();
                int duracao = Integer.parseInt(txtDuracao.getText().trim());
                double valor = Double.parseDouble(txtValor.getText().trim());

                Servico servico = new Servico(nome, duracao, valor);
                Sistema.servicos.add(servico);
                Sistema.salvarServicos();

                JOptionPane.showMessageDialog(this, "Serviço cadastrado:\n" + servico);
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Dados inválidos. Verifique os campos.");
            }
        });

        painelPrincipal.add(painelForm);
        add(painelPrincipal);
        setVisible(true);
    }
}