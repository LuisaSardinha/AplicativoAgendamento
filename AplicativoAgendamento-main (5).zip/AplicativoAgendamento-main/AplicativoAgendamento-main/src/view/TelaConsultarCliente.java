package view;

import javax.swing.*;
import java.awt.*;
import model.Cliente;
import model.Sistema;

public class TelaConsultarCliente extends JFrame {
    public TelaConsultarCliente() {
        setTitle("Consultar Cliente");
        setSize(450, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fundo = new Color(240, 245, 255);
        Color destaque = new Color(45, 120, 240);
        Color hover = new Color(30, 100, 200);
        Color branco = Color.WHITE;

        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        painelPrincipal.setBackground(fundo);

        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setPreferredSize(new Dimension(380, 220));
        painelForm.setBackground(branco);
        painelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(destaque, 2, true),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitulo = new JLabel("Consultar Cliente");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(destaque);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        painelForm.add(lblTitulo, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        painelForm.add(new JLabel("Buscar por:"), gbc);

        JComboBox<String> cbOpcao = new JComboBox<>(new String[]{"ID", "Nome"});
        cbOpcao.setPreferredSize(new Dimension(200, 25));
        gbc.gridx = 1;
        painelForm.add(cbOpcao, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        painelForm.add(new JLabel("Valor:"), gbc);

        JTextField txtBusca = new JTextField();
        txtBusca.setPreferredSize(new Dimension(200, 25));
        gbc.gridx = 1;
        painelForm.add(txtBusca, gbc);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBuscar.setBackground(destaque);
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBuscar.setBackground(hover);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBuscar.setBackground(destaque);
            }
        });

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        painelForm.add(btnBuscar, gbc);

        btnBuscar.addActionListener(e -> {
            String tipoBusca = (String) cbOpcao.getSelectedItem();
            String valor = txtBusca.getText().trim();
            Cliente resultado = null;

            if (tipoBusca.equals("ID")) {
                try {
                    int id = Integer.parseInt(valor);
                    for (Cliente c : Sistema.clientes) {
                        if (c.getId() == id) {
                            resultado = c;
                            break;
                        }
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "ID inválido.");
                    return;
                }
            } else {
                for (Cliente c : Sistema.clientes) {
                    if (c.getNome().equalsIgnoreCase(valor)) {
                        resultado = c;
                        break;
                    }
                }
            }

            if (resultado != null) {
                JOptionPane.showMessageDialog(this, "Cliente encontrado:\n" + resultado);
            } else {
                JOptionPane.showMessageDialog(this, "Cliente não encontrado.");
            }
        });

        painelPrincipal.add(painelForm);
        add(painelPrincipal);
        setVisible(true);
    }
}