package view;

import javax.swing.*;
import java.awt.*;
import java.util.PriorityQueue;
import model.Cliente;
import model.Sistema;

public class TelaListarFila extends JFrame {
    public TelaListarFila() {
        setTitle("Fila de Espera");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fundo = new Color(240, 245, 255);
        Color destaque = new Color(45, 120, 240);
        Color branco = Color.WHITE;

        JPanel painelExterno = new JPanel(new BorderLayout(10, 10));
        painelExterno.setBackground(fundo);
        painelExterno.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titulo = new JLabel("Fila de Espera");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(destaque);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);

        JTextArea txtArea = new JTextArea();
        txtArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtArea.setEditable(false);
        txtArea.setBackground(branco);
        txtArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(destaque, 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        PriorityQueue<Cliente> filaTemp = new PriorityQueue<>(Sistema.filaEspera);
        StringBuilder sb = new StringBuilder();

        if (filaTemp.isEmpty()) {
            sb.append("Nenhum cliente na fila.");
        } else {
            int posicao = 1;
            while (!filaTemp.isEmpty()) {
                Cliente c = filaTemp.poll();
                sb.append(posicao++).append(". ").append(c).append("\n");
            }
        }

        txtArea.setText(sb.toString());

        painelExterno.add(titulo, BorderLayout.NORTH);
        painelExterno.add(new JScrollPane(txtArea), BorderLayout.CENTER);

        add(painelExterno);
        setVisible(true);
    }
}