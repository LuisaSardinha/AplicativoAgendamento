package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import model.Sistema;

public class TelaPrincipal extends JFrame {

    public TelaPrincipal() {
        setTitle("Sistema de Agendamento");
        setSize(500, 520);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Color fundo = new Color(240, 245, 255);      // Fundo claro
        Color corBotao = new Color(45, 120, 240);    // Azul moderno
        Color corHover = new Color(30, 100, 200);
        Color corTexto = Color.WHITE;

        JPanel painelExterno = new JPanel(new GridBagLayout());
        painelExterno.setBackground(fundo);

        JPanel painelInterno = new JPanel();
        painelInterno.setLayout(new BoxLayout(painelInterno, BoxLayout.Y_AXIS));
        painelInterno.setPreferredSize(new Dimension(320, 420));
        painelInterno.setBackground(Color.WHITE);
        painelInterno.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(corBotao, 2, true),
                BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        JLabel titulo = new JLabel("Sistema de Agendamento");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(corBotao);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 25, 0));
        painelInterno.add(titulo);

        String[] textos = {
                "Inserir Cliente na Fila", "Agendar Cliente", "Consultar Cliente",
                "Listar Fila", "Listar Agendamentos", "Cadastrar Serviço"
        };

        Runnable[] acoes = {
                () -> new TelaInserirCliente(),
                () -> new TelaAgendarCliente(),
                () -> new TelaConsultarCliente(),
                () -> new TelaListarFila(),
                () -> new TelaListarAgendamentos(),
                () -> new TelaCadastrarServico()
        };

        for (int i = 0; i < textos.length; i++) {
            JButton botao = new JButton(textos[i]);
            botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
            botao.setForeground(corTexto);
            botao.setBackground(corBotao);
            botao.setFocusPainted(false);
            botao.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
            botao.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
            botao.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Hover visual
            botao.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    botao.setBackground(corHover);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    botao.setBackground(corBotao);
                }
            });

            final int idx = i;
            botao.addActionListener(e -> acoes[idx].run());

            painelInterno.add(botao);
            painelInterno.add(Box.createRigidArea(new Dimension(0, 12)));
        }

        painelExterno.add(painelInterno);
        add(painelExterno);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Sistema.inicializarSistema();
            new TelaPrincipal();
        });
    }
}