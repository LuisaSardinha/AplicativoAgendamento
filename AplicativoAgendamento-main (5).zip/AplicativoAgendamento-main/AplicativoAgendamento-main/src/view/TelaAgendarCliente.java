package view;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import model.Cliente;
import model.Agendamento;
import model.Servico;
import model.Sistema;

public class TelaAgendarCliente extends JFrame {

    public TelaAgendarCliente() {
        setTitle("Agendar Cliente");
        setSize(500, 370);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fundo = new Color(240, 245, 255);
        Color destaque = new Color(45, 120, 240);
        Color hover = new Color(30, 100, 200);
        Color branco = Color.WHITE;

        Cliente cliente = Sistema.filaEspera.poll();
        if (cliente == null) {
            JOptionPane.showMessageDialog(this, "Nenhum cliente na fila.");
            dispose();
            return;
        }

        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        painelPrincipal.setBackground(fundo);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setBackground(branco);
        painelForm.setPreferredSize(new Dimension(380, 280));
        painelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(destaque, 2, true),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblTitulo = new JLabel("Agendamento");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(destaque);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 0;
        painelForm.add(lblTitulo, gbc);

        // Cliente info
        gbc.gridy++;
        JLabel lblInfo = new JLabel("Cliente: " + cliente.getNome());
        lblInfo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        painelForm.add(lblInfo, gbc);

        // Serviço
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        painelForm.add(new JLabel("Serviço:"), gbc);

        JComboBox<Servico> comboServicos = new JComboBox<>(Sistema.servicos.toArray(new Servico[0]));
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(comboServicos, gbc);

        // Data e Hora
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.weightx = 0;
        painelForm.add(new JLabel("Data e Hora:"), gbc);

        JTextField txtDataHora = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(txtDataHora, gbc);

        JLabel lblFormato = new JLabel("(dd/MM/yyyy HH:mm)");
        lblFormato.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblFormato.setForeground(Color.GRAY);
        gbc.gridy++;
        gbc.gridx = 1;
        gbc.weightx = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.WEST;
        painelForm.add(lblFormato, gbc);

        // Botão
        JButton btnConfirmar = new JButton("Confirmar");
        btnConfirmar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnConfirmar.setBackground(destaque);
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFocusPainted(false);
        btnConfirmar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        btnConfirmar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnConfirmar.setBackground(hover);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnConfirmar.setBackground(destaque);
            }
        });

        btnConfirmar.addActionListener(e -> {
            try {
                String dataHoraStr = txtDataHora.getText().trim();
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                Date dataHora = sdf.parse(dataHoraStr);

                Servico servicoSelecionado = (Servico) comboServicos.getSelectedItem();
                if (servicoSelecionado == null) {
                    JOptionPane.showMessageDialog(this, "Nenhum serviço selecionado.");
                    return;
                }

                Agendamento agendamento = new Agendamento(cliente, dataHora, servicoSelecionado);
                Sistema.agendamentos.add(agendamento);
                Sistema.salvarAgendamentos();

                JOptionPane.showMessageDialog(this, "Agendamento realizado:\n" + agendamento);
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Data inválida. Use formato dd/MM/yyyy HH:mm");
            }
        });

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        painelForm.add(btnConfirmar, gbc);

        painelPrincipal.add(painelForm);
        add(painelPrincipal);
        setVisible(true);
    }
}