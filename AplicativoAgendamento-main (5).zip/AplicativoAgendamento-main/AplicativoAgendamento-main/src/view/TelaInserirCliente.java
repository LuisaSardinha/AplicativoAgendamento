package view;

import javax.swing.*;
import java.awt.*;
import model.Cliente;
import model.Sistema;

public class TelaInserirCliente extends JFrame {
    public TelaInserirCliente() {
        setTitle("Inserir Cliente na Fila");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fundo = new Color(240, 245, 255);
        Color destaque = new Color(45, 120, 240);
        Color hover = new Color(30, 100, 200);
        Color branco = Color.WHITE;

        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        painelPrincipal.setBackground(fundo);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setBackground(branco);
        painelForm.setPreferredSize(new Dimension(380, 260));
        painelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(destaque, 2, true),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblTitulo = new JLabel("Inserir Cliente na Fila");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(destaque);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        painelForm.add(lblTitulo, gbc);

        // Nome
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.weightx = 0;
        painelForm.add(new JLabel("Nome:"), gbc);

        JTextField txtNome = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(txtNome, gbc);

        // Telefone
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        painelForm.add(new JLabel("Telefone:"), gbc);

        JTextField txtTelefone = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(txtTelefone, gbc);

        // ID
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        painelForm.add(new JLabel("ID:"), gbc);

        JTextField txtID = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        painelForm.add(txtID, gbc);

        // Botão
        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSalvar.setBackground(destaque);
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.setFocusPainted(false);
        btnSalvar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        btnSalvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnSalvar.setBackground(hover);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSalvar.setBackground(destaque);
            }
        });

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        painelForm.add(btnSalvar, gbc);

        btnSalvar.addActionListener(e -> {
            try {
                String nome = txtNome.getText().trim();
                String telefone = txtTelefone.getText().trim();
                int id = Integer.parseInt(txtID.getText().trim());

                String[] opcoes = {"1 - Alta", "2 - Média", "3 - Baixa"};
                String prioridadeStr = (String) JOptionPane.showInputDialog(this,
                        "Selecione a prioridade:", "Prioridade",
                        JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[1]);

                if (prioridadeStr == null) return;

                int prioridade = Integer.parseInt(prioridadeStr.substring(0, 1));
                Cliente cliente = new Cliente(nome, telefone, id, prioridade);
                Sistema.adicionarCliente(cliente);

                JOptionPane.showMessageDialog(this, "Cliente cadastrado: " + cliente);
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID inválido.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
            }
        });

        painelPrincipal.add(painelForm);
        add(painelPrincipal);
        setVisible(true);
    }
}