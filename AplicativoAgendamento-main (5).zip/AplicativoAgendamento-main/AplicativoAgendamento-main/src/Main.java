package view;
import view.TelaPrincipal;
import javax.swing.SwingUtilities;
import model.Sistema;


public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Sistema.inicializarSistema();
            new TelaPrincipal();
        });
    }
}

